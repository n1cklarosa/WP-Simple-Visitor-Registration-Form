=== Plugin Name ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: https://nicklarosa.net
Tags: registration
Requires at least: 5.0
Tested up to: 5.4
Stable tag: 5.0
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add a simple visitor registration form to any wordpress content

== Description ==

Add a simple visitor registration form to any wordpress content

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload project to your plugins folder in its own directory. eg. to the `/wp-content/plugins/WP-simple-visitor-registration/` directory.
2. Head to your plugin screen to activate it

== Frequently Asked Questions ==

= Can the form use google reCAPTCHA? =

Yes, set up the approriate fields in the new settings field

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png`
(or jpg, jpeg, gif).
2. This is the second screen shot

== Changelog ==

= 1.0 =
* Initial Version